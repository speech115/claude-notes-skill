# TL;DR + Appendix Agent Prompt

Launch **ONE** agent that reads ONLY the summary files (not all blocks — saves context).

## Prompt

```
Read all summary_chunk_*.md files in $WORK_DIR (sorted).
Also scan all manifest_chunk_*.tsv files for names, resources, and cases columns.

Write TWO files:

1. $WORK_DIR/tldr.md
Numbered key takeaways. Just the list, no heading. One sentence each.
Based on the summaries you read.

Determine the number of takeaways based on content volume:
- If there is 1 summary file (short recording): 5 takeaways
- If there are 2 summary files: 7-10 takeaways
- If there are 3-4 summary files: 10-12 takeaways
- If there are 5+ summary files: 12-15 takeaways

2. $WORK_DIR/appendix.md
Contains these sections:

# Упомянутые люди и ресурсы

## Люди
- **[Имя]:** [why they matter in this material]
[Deduplicated from manifest names column + any found in summary files. IMPORTANT: include ALL people — not just speakers/participants, but also people discussed as examples, case study subjects, mentors referenced by name, public figures cited, authors of books mentioned, etc.]

## Ресурсы
- **[Resource]:** [why it matters here]
[From manifest resources column — books, tools, platforms, apps, services. Deduplicated.]

---

# План действий

### Прямо сейчас
- [ ] [3-5 concrete actions]

### На этой неделе
- [ ] [3-5 actions]

### На постоянной основе
- [ ] [5-7 habits/principles]

---

# Ключевые идеи и модели
- **[Model / idea]:** [1-2 sentence explanation]
- **[Model / idea]:** [1-2 sentence explanation]

Output in Russian. Only use information from the files — do NOT invent.
Do NOT add version numbers, model names, or facts from your own knowledge — only what appears in the source files. If a file says "Claude" without a version, write "Claude", not "Claude Opus 4.5".
```
